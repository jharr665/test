# Media Stack (Traefik + Authelia + Gluetun + Jellyfin/*arr + Immich + Navidrome + Calibre Web + n8n + Notion + Tailscale + Vaultwarden)

This is a ready-to-run Docker Compose stack for a homelab media and automation setup.

## Quickstart
1. Copy `.env.example` to `.env` and fill values (domain, timezone, VPN, secrets).
2. Create/mount storage on the host:
   - `/mnt/media/{movies,tv,music,books,photos}`
   - `/mnt/downloads`
3. Bring it up:
   ```bash
   docker compose up -d
   ```
4. Add DNS entries (internal or public) for `*.${TRAEFIK_DOMAIN}` pointing to your server.

## Access URLs (replace domain)
- Traefik Dashboard: `https://traefik.${TRAEFIK_DOMAIN}` (Authelia-protected)
- Jellyfin: `https://jellyfin.${TRAEFIK_DOMAIN}`
- qBittorrent (via VPN): `https://qbt.${TRAEFIK_DOMAIN}`
- Radarr/Sonarr/Lidarr/Readarr: `https://radarr.${TRAEFIK_DOMAIN}`, etc.
- Prowlarr: `https://prowlarr.${TRAEFIK_DOMAIN}`
- Bazarr: `https://bazarr.${TRAEFIK_DOMAIN}`
- Requests (Jellyseerr): `https://requests.${TRAEFIK_DOMAIN}`
- Immich: `https://immich.${TRAEFIK_DOMAIN}`
- Navidrome: `https://music.${TRAEFIK_DOMAIN}`
- Calibre Web: `https://books.${TRAEFIK_DOMAIN}`
- n8n: `https://n8n.${TRAEFIK_DOMAIN}`
- Vaultwarden: `https://vault.${TRAEFIK_DOMAIN}`

## n8n + Notion
- Import `n8n-workflows/job_apply_assistant.json` in n8n.
- Create Notion integration & DB; set `NOTION_DB_ID` env in n8n or edit the node.
- Configure SMTP & (optional) OpenAI credentials in n8n for drafting cover letters.

## Tailscale
- Use the OPNsense plugin (recommended) or the included container service.
- Example ACL policy in `tailscale/acls-example.json`.

## Security
- Prefer VPN-only access for sensitive apps (Vaultwarden, qBittorrent, Prowlarr, n8n).
- Keep Authelia enabled for all public routes; enable 2FA.
- Respect laws and ToS for job boards and content sources.
